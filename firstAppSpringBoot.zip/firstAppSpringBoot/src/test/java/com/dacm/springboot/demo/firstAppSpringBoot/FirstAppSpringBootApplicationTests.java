package com.dacm.springboot.demo.firstAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
